from flask import Flask, render_template, request, Response, url_for, send_file
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import pandas as pd
from sqlalchemy import create_engine
import networkx as nx
import matplotlib.pyplot as plt
import os
from io import BytesIO

engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}".format(
    user='root',
    pw='#Vamshi869',
    db='game_db'
))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/success', methods=["GET", "POST"])
def success():
    if request.method == 'POST':
        f = request.files['file']
        f.save(f.filename)
        game = pd.read_csv("game.csv")
        game = game.iloc[:, :]
        game.columns
        
        for_g = nx.Graph()
        for_g = nx.from_pandas_edgelist(game, source='Source', target='Target')
        data = pd.DataFrame({
            "closeness": pd.Series(nx.closeness_centrality(for_g)),  # Closeness centrality
            "Degree": pd.Series(nx.degree_centrality(for_g)),  # Degree centrality
            "eigenvector": pd.Series(nx.eigenvector_centrality(for_g)),  # Eigenvector centrality
            "betweenness": pd.Series(nx.betweenness_centrality(for_g)), # Betweenness centrality
            "cluster":pd.Series(nx.clustering(for_g)),# cluster
        })
        
        
        data.to_sql('centralities', con = engine, if_exists='replace', chunksize=1000, index=False)
        html_table = data.to_html(classes='table table-striped')
        
        return render_template("data.html", frame = f"<style>\
                               .table {{\
                                        width: 50%;\
                                        margine: 0 auto;\
                                        border-collapse: collapse;\
                                    }}\
                                   .table thead {{\
                                        background-color: #3ee6ca;\
                                    }}\
                                     .table th, .table td {{\
                                        border: 1px solid #ddd;\
                                    }}\
                                    .table td {{\
                                    background-color: #ed2bc6;\
                                    }}\
                                        .table tbody th {{\
                                        background-color: #ab2c3f;\
                                        }}\
                                </style>\
                                {html_table}")
                                
@app.route('/plots')
def plots():
    return render_template('plot.html')
@app.route('/graph')
def graph():
    game = pd.read_csv("game.csv")
    game = game.iloc[:, :]

    # Create the graph from the data
    for_g = nx.Graph()
    for_g = nx.from_pandas_edgelist(game, source='Source', target='Target')

    # Create a matplotlib figure
    plt.figure(figsize=(10, 6))
    pos = nx.spring_layout(for_g)  # positions for all nodes
    nx.draw(for_g, pos, with_labels=True, node_size=700, node_color='lightblue', font_size=10, font_color='black', font_weight='bold', edge_color='gray')

    # Save the figure to a BytesIO object
    output = BytesIO()
    FigureCanvas(plt.gcf()).print_png(output)
    output.seek(0)

    return Response(output, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
