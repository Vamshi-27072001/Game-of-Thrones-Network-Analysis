import pandas as pd  # Import pandas for data manipulation
import networkx as nx  # Import NetworkX for graph creation and analysis
import matplotlib.pyplot as plt  # Import Matplotlib for plotting
from sqlalchemy import create_engine #
import pymysql

# Load data from a CSV file into a DataFrame
game = pd.read_csv(r"C:\Users\HP\Desktop\uploaded_files/game.csv")

user = 'root' # uesr
host = 'localhost' #localhost
pw = '#Vamshi869' # password
db = 'game_db' # database name

#create the engine 
engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}".format(user = 'root',
                                                                            pw = '#Vamshi869',
                                                                            db = 'game_db'))
# Loding data into sql database
game.to_sql('game', con = engine, if_exists = 'replace', chunksize = 1000, index = False)

#Reading data from sql database
sql = 'select * from game;'
game = pd.read_sql_query(sql, con = engine)

# Display the first few rows of the DataFrame
game.head()

# Select the first 684 rows and the first 5 columns of the DataFrame
game = game.iloc[:, :]

# Create an empty undirected graph
for_g = nx.Graph()

# Create a graph from the DataFrame, using 'Source' and 'Target' as edges
for_g = nx.from_pandas_edgelist(game, source='Source', target='Target')

# Count the number of nodes in the graph
num_nodes = for_g.number_of_nodes()

# Count the number of edges in the graph
num_edges = for_g.number_of_edges()

# Print the number of nodes and edges
print(f"Number of nodes: {num_nodes}")
print(f"Number of edges: {num_edges}")

# Calculate centrality measures and store them in a DataFrame
data = pd.DataFrame({
    "closeness": pd.Series(nx.closeness_centrality(for_g)),  # Closeness centrality
    "Degree": pd.Series(nx.degree_centrality(for_g)),  # Degree centrality
    "eigenvector": pd.Series(nx.eigenvector_centrality(for_g)),  # Eigenvector centrality
    "betweenness": pd.Series(nx.betweenness_centrality(for_g)), # Betweenness centrality
    "cluster":pd.Series(nx.clustering(for_g)),# cluster
})

# Sort and display the top 10 characters based on Degree centrality
top_10_degree = data.sort_values(by='Degree', ascending=False).head(10)
print("Top 10 characters based on Degree Centrality:")
print(top_10_degree)


# Visualization of the top 10 characters based on Degree Centrality
plt.figure(figsize=(10, 6))
top_10_degree['Degree'].plot(kind='bar', color='skyblue')
plt.title('Top 10 Characters Based on Degree Centrality')
plt.xlabel('Characters')
plt.ylabel('Degree Centrality')
plt.xticks(rotation=45)  # Rotate x labels for better visibility
plt.grid(axis='y')

# Display the plot
plt.show()

# Sort and display the top 10 characters based on closeness centrality
top_10_closeness = data.sort_values(by='closeness', ascending=False).head(10)
print("Top 10 characters based on closeness Centrality:")
print(top_10_closeness)

# Display the DataFrame containing centrality measures
data
# Create a new figure for plotting

# Sort and select the top 10 characters based on Degree centrality
top_10_degree = data.sort_values(by='Degree', ascending=False).head(10)

# Create a subgraph containing only the top 10 nodes
top_10_nodes = top_10_degree.index.tolist()  # Assuming the index corresponds to the characters' names
subgraph = for_g.subgraph(top_10_nodes)

# Create a new figure for plotting
plt.figure(figsize=(8, 6))

# Generate positions for the nodes using spring layout
pos = nx.spring_layout(subgraph, k=0.15)

# Draw the subgraph with specified parameters
nx.draw_networkx(subgraph, pos, node_size=500, node_color='blue', with_labels=True, font_size=10)

# Display the plot
plt.title("Top 10 Characters Based on Degree Centrality")
plt.axis('off')  # Hide the axes for better visualization
plt.show()
